# Blog Praktikum SQL II

Website blog sederhana untuk laporan praktikum Pemrograman SQL II.

## Fitur
- Tampilan modern
- Materi per level
- Responsive design
- Siap upload ke GitHub

## Cara Menjalankan
Buka file `index.html` di browser.
