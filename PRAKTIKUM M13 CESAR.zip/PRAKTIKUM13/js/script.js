 // =========================
 // BACK TO TOP BUTTON
 // =========================

const btn = document.createElement("button");
btn.innerText = "↑";
btn.classList.add("btn-top");
document.body.appendChild(btn);

btn.style.position = "fixed";
btn.style.bottom = "20px";
btn.style.right = "20px";
btn.style.padding = "10px 15px";
btn.style.border = "none";
btn.style.borderRadius = "50%";
btn.style.background = "#2563eb";
btn.style.color = "white";
btn.style.fontSize = "18px";
btn.style.cursor = "pointer";
btn.style.display = "none";
btn.style.boxShadow = "0 5px 15px rgba(0,0,0,.2)";

// tampil saat scroll
window.addEventListener("scroll", () => {
    if (window.scrollY > 200) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
});

// kembali ke atas
btn.addEventListener("click", () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});